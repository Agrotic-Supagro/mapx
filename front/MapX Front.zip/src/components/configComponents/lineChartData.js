export function getLineChartData(phfbMeasures_2022, phfbMeasures_2023, phfbMeasures_2024) { 
    return {
        type: 'scatter',
        data: {
        datasets: [
            {
                label: "2022",
                data: phfbMeasures_2022,
                backgroundColor: "rgba(54,73,93,.5)",
                borderColor: "#36495d",
                borderWidth: 3,
                hidden: true
            },
            {
                label: "2023",
                data: phfbMeasures_2023,
                backgroundColor: "rgba(71, 183,132,.5)",
                borderColor: "#47b784",
                borderWidth: 3,
                hidden: true
            },
            {
                label: "2024",
                data: phfbMeasures_2024,
                backgroundColor: "rgba(255, 99,71,.5)",
                borderColor: "#c12d18",
                borderWidth: 3
            }
        ]
        },
        options: {
            responsive: true,
            lineTension: 0,
            scales: {
                xAxes: 
                {
                    ticks: {
                        beginAtZero: true,
                    },
                    type: "time",
                    time: {
                        unit: "month",
                    },
                }
            }
        }
  }
}