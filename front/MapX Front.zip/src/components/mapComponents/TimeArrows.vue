<template>
    <div class="d-inline-block timeArrows">
        <VueDatePicker v-model="selectedDate" locale="fr" cancelText="Annuler" selectText="Sélectionner" format="dd/MM/yyyy" @update:model-value="dateUpdate"></VueDatePicker>
    </div>
</template>

<script>
import VueDatePicker from '@vuepic/vue-datepicker';
import '@vuepic/vue-datepicker/dist/main.css'

export default{
    name:'TimeArrows',
    props: {
        day: Boolean,
        current_date: Date,
    },
    data(){
      return {
        selectedDate: this.current_date,
      }
    },
    watch: {
        current_date(newDate) {
            this.selectedDate = newDate;
        }
    },
    components: {
        VueDatePicker,
    },
    methods: {
        getDayFromDate(date) {
            const week_days = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
            return week_days[date.getDay()];
        },
        dateUpdate(date) {
            console.log('date update: ', date);
            this.$emit('new-date', date);
        },
    },
}
</script>


<style scoped>
    .arrow-button {
    border: none;
    width: 30px;
    height: 30px;
    background-color: rgb(222,235,247);
    cursor: pointer;
    border-radius: 20%;
    box-shadow: 4px 4px 5px rgba(0, 0, 0, 0.3); /* Offset-x, Offset-y, Blur-radius, Color */
    
    }

    .arrow-button:hover {
        background-color: rgb(214, 224, 232);;
    }
    .arrowText{
        margin: 0px 20px;
    }

    .timeArrows{
        width: 160px;
    }
</style>