<template>
    <form @submit.prevent="login">
        <div class="formGroup">
            <label class="label" for="exampleInputEmail1">Email</label>
            <input type="email" v-model="user.email" id="exampleInputEmail1" placeholder="Entrez votre email">
        </div>
        <div class="formGroup">
            <label for="exampleInputPassword1">Mot de passe</label>
            <input type="password" v-model="user.password" class="form-control" id="exampleInputPassword1" placeholder="Entrez votre mot de passe">
        </div>
        <div>
            <button type="submit">Valider</button>
        </div>
    </form>
    <LoadingSpinner v-if="isLoggingIn"></LoadingSpinner>
</template>

<script>
import * as backend_services from '@/services/backend_services'
import LoadingSpinner from "@/components/animatedComponents/LoadingSpinner.vue"
import * as db_interaction from '@/services/db_interaction'

export default {
    components: {
        LoadingSpinner
    },
    name: 'Login',
    data(){
        return {
            user: {
                email:'',
                password:'',
            },
            isLoggingIn: false
        }
    },
    methods: {
        // checks if a spider model exists (by checking if there's a ref parcel)
        async existingSpiderModel() {
            const refParcel = await db_interaction.getRefParcelSpiderModel();
            if (refParcel == null) {
                localStorage.setItem('existingSpiderModel', false);
            } else {
                localStorage.setItem('existingSpiderModel', true);
                localStorage.setItem('refParcel', refParcel);
            }
        },
        async login(){
            localStorage.clear();
            this.isLoggingIn = true;
            let token = null;
            const res = await backend_services.login(this.user.email, this.user.password)
            this.isLoggingIn = false;
            if (res === undefined){
                console.log('not logged in');
            } else  {
                token = res['token'];
                console.log('token: ', token);
                localStorage.setItem('token', token);
                // check if existing spider model
                let existingModel = await this.existingSpiderModel();
                this.$router.push({ path: '/mapView'});
            }
        }
    }
}
</script>

<style scoped>
    form{
        max-width: 300px;
        margin: 0 auto;
        position: absolute;
        top: 30%;
        left: 40%;
    }
    .formGroup{
        display: flex;
        justify-content: space-between;
        margin-bottom: 15px;
        margin-left: 5px;
    }

    label{
        margin-right: 10px;
        font-weight: bold;
    }

    button{
        position: absolute;
        margin-top:20px;
        left: 55%;
    } 

    input:hover{
        border: 2px solid #3498db; /* Change border color when hovering */
        background-color: #f2f2f2; /* Change background color when hovering */
        color: #333; /* Change text color when hovering */
    }

    input:focus {
        outline: none; /* Remove default focus outline */
        border: 1.5px solid #000000; /* Change border color when focused */
        background-color: #ecf0f1; /* Change background color when focused */
        color: #333; /* Change text color when focused */
    }
    
    button:hover{
        cursor: pointer;
        border: 2px solid #1f72aa; /* Change border color when focused */
        transform: scale(1.1);
    } 

</style>