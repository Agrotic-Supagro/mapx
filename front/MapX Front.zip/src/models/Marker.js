export default class Marker {
    constructor(id, latitude, longitude, measure_type, constraint_class){
        this.id = id;
        this.latitude = latitude;
        this.longitude = longitude;
        this.measure_type = measure_type;
        this.constraint_class = constraint_class;
    }
};