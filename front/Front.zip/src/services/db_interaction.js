import Measure from '@/models/Measure.js';
import * as date_functions from '@/services/date_functions'

const baseURL = `http://localhost:5000/`;
// const baseURL = 'https://mxv-back.servadmin.fr/';
// const baseURL = `http://mapx-vigne.agrotic.org/python`;/home/agrotic/mapx-vigne.agrotic.org/python
// const baseURL = 'https://mxv-back-dev.servadmin.fr/';

// get lat and long of a specified parcel
export const getLatLongParcel = async (parcelName) => {
    const token = localStorage.getItem('token');
    try{
        // fetch the data
        const res = await fetch(baseURL + `getLatLongParcel?parcelName=${parcelName.toString()}`, {
            method: 'GET',
            headers: {
                'content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        const result = await res.json();
        return result[0];

        } catch(error) {
            console.error(error.message);
        }
}

export const getLatestPHFBMeasureDate = async (territory) => {
    const token = localStorage.getItem('token');
    try{
        const queryParams = new URLSearchParams();
        queryParams.append('territory', territory);
        // fetch the data
        const res = await fetch(baseURL + `getLatestPHFBMeasureDate?territory=${territory.toString()}`, {
            method: 'GET',
            headers: {
                'content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        const result = await res.json();
        return result[0];

        } catch(error) {
            console.error(error.message);
        }
};

export const getUserParcelIDs = async () => {
    const token = localStorage.getItem('token');
    try{
        // fetch the data
        const res = await fetch(baseURL + `getUserParcelIDs`, {
            method: 'GET',
            headers: {
                'content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        
        const IDs = await res.json();

        // make an array of Measures
        let parcelIDs = [];
        IDs.forEach((id) => {
            parcelIDs.push(id[0]);
        });

        return parcelIDs;

        } catch(error) {
            console.error(error.message);
        }
};


export const getICAPEXMeasures = async (startDate, endDate) => {
    const token = localStorage.getItem('token');
    try{
        const queryParams = new URLSearchParams();
        queryParams.append('startDate', startDate);
        queryParams.append('endDate', endDate);

        // fetch the data
        //const res = await fetch('http://localhost:5000/get_data?${queryParams.toString()});
        const res = await fetch(baseURL + `getICAPEXMeasures?startDate=${startDate.toString()}&endDate=${endDate.toString()}`, {
            method: 'GET',
            // mode: 'no-cors',
            headers: {
                'content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        
        const observations = await res.json();

        // make an array of Measures
        let measures = [];
        observations.forEach((obs) => {
            measures.push(new Measure(obs.id,obs.parcel_name, obs.apex_value, obs.measure_type, obs.type, obs.date, obs.reliability, obs.latitude, obs.longitude, 'none'));
        });

        return measures;

        } catch(error) {
            console.error(error.message);
        }
};


export const getPHFBMeasures = async (startDate, endDate, territory) => {
    const token = localStorage.getItem('token');
    try{
        const queryParams = new URLSearchParams();
        queryParams.append('startDate', startDate);
        queryParams.append('endDate', endDate);
        queryParams.append('territory', territory);

        // fetch the data
        const res = await fetch(baseURL + `getPHFBMeasures?startDate=${startDate.toString()}&endDate=${endDate.toString()}&territory=${territory.toString()}`, {
            method: 'GET',
            // mode: 'no-cors',
            headers: {
                'content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        });
        
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        
        const observations = await res.json();

        // make an array of Measures
        let measures = [];
        observations.forEach((obs) => {
            // format date to mm/dd/yyyy
            const dateParts = obs.date.split("/");
            const date =  new Date(dateParts[1] + "/" + dateParts[0] + "/" + dateParts[2]);
            // add measure
            // process constraint class according to measure's date and phfb value
            const constraint_class = date_functions.getClassConstraintFromDate(date, Number(obs.phfb_value.replace(",",".")));
            measures.push(new Measure(parseInt(obs.id),obs.parcel_name, Number(obs.phfb_value.replace(",",".")), obs.measure_type, obs.type, date, obs.reliability, Number(obs.latitude.replace(",",".")), Number(obs.longitude.replace(",",".")), constraint_class));
        });

        return measures;

        } catch(error) {
            console.error(error.message);
        }
};

export const testingMethod = async () => {
    try{
        // fetch the data
        const res = await fetch(baseURL + `testingMethod`);
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
    }
    catch(error) {
        console.error(error.message);
    }
};

export const getSpiderCoeffs = async () => {
    try{
        // fetch the data
        const res = await fetch(baseURL + `getCoeffs`);
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        
        const coeffs = await res.json();

        return coeffs;

        } catch(error) {
            console.error(error.message);
        }
};

export const deleteSpiderModel = async () => {
    try{
        // fetch the data
        const res = await fetch(baseURL + `deleteSpiderModel`);
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        
        const result = await res.json();
        return result;

        } catch(error) {
            console.error(error.message);
        }
};


export const getRefParcelSpiderModel = async () => {
    try{
        // fetch the data
        const res = await fetch(baseURL + `getRefParcelSpiderModel`);
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        
        const result = await res.json();

        return result;

        } catch(error) {
            console.error(error.message);
        }
};

export const getValidSeasonsSpiderModel = async () => {
    try{
        // fetch the data
        const res = await fetch(baseURL + `getValidSeasonsSpiderModel`);
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        
        const result = await res.json();

        return result;

        } catch(error) {
            console.error(error.message);
        }
};

// get all seasons (for PHFB measures) of a specified parcel
export const getSeasonsPHFBParcel = async (parcel) => {
    const queryParams = new URLSearchParams();
    queryParams.append('parcel', parcel);

    try{
        // fetch the data
        const res = await fetch(baseURL + `getSeasonsPHFBParcel?parcel=${parcel.toString()}`);
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        
        const result = await res.json();

        return result;

        } catch(error) {
            console.error(error.message);
        }
};




export const computeSpiderCoefficients = async (seasons, candidateSatelliteParcels, refParcel) => {
    try{
        const queryParams = new URLSearchParams();
        queryParams.append('seasons', seasons);
        queryParams.append('candidateSatelliteParcels', candidateSatelliteParcels);
        queryParams.append('refParcel', refParcel);

        // fetch the data
        const res = await fetch(baseURL + `computeSpiderCoefficients?seasons=${seasons.toString()}&candidateSatelliteParcels=${candidateSatelliteParcels.toString()}&refParcel=${refParcel.toString()}`);
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        
        const coeffs = await res.json();

        return coeffs;

        } catch(error) {
            console.error(error.message);
        }
};

// add a measure for the specified parcel in the DB
// measureType = {'PHFB', 'IC-APEX'}
// TODO: add another check to see if it's an IC-APEX measure, if yes call the function insertICAPEXMeasure (to define in app.py)
export const addMeasureParcel = async (measureType, value, parcel, date, latitude, longitude) => {
    try{
        const queryParams = new URLSearchParams();
        queryParams.append('value', value);
        queryParams.append('parcel', parcel);
        queryParams.append('date', date);
        queryParams.append('latitude', latitude);
        queryParams.append('longitude', longitude);
        let res;
        if (measureType === 'PHFB'){
            res = await fetch(baseURL + `insertPHFBMeasure?value=${value.toString()}&parcel=${parcel.toString()}&date=${date.toString()}&latitude=${latitude.toString()}&longitude=${longitude.toString()}`,{method: 'POST'});
        }
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }

        } catch(error) {
            console.error(error.message);
        }
};

export const getMeasuresParcel = async (parcel) => {
    try {
        const queryParams = new URLSearchParams();
        queryParams.append('parcel', parcel);
        let res;

        res = await fetch(baseURL + `getParcelMeasures?parcel=${parcel.toString()}`);
        
        if (!res.ok) {
            const message = 'Error';
            throw new Error(message);
        }

        const measures = await res.json();

        return measures;

    } catch(error) {
        console.error(error.message);
    }
}