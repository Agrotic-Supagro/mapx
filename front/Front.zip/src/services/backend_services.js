const baseURL = `http://localhost:5000/`;
// const baseURL = 'https://mxv-back.servadmin.fr/';
// const baseURL = 'https://mxv-back-dev.servadmin.fr/';


// login function
export const login = async (email, password) => {
  const formData = {
    email: email,
    password: password,
  };
  
  try{
    // fetch the data
    const res = await fetch(baseURL+ 'login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
    });
    
    if (!res.ok) {
      const message = 'error logging in';
      throw new Error(message);
    }
    
    const response = await res.json();
    return response;

    } catch(error) {
        console.error(error.message);    
    }
}

// upload file function
export const uploadCSVFile = async () => {
  const token = localStorage.getItem('token');
  try{
      // fetch the data
      const res = await fetch(baseURL + 'uploadCSVFile', {
          method: 'POST',
          headers: {
              'content-Type': 'application/json',
              'Authorization': `Bearer ${token}`
          }
      });
      if (!res.ok) {
        const message = 'Error';
        throw new Error(message);
      }
      
      const result = await res.json();

      return result;

      } catch(error) {
          console.error(error.message);
      }
};

// returns a list of all parcel names
export const getParcelNames = async (territory) => {
    try{
        // fetch the data
        const res = await fetch(baseURL + `getParcelNames?territory=${territory.toString()}`);
        if (!res.ok) {
          const message = 'Error';
          throw new Error(message);
        }
        
        const parcelNames = await res.json();

        return parcelNames;

        } catch(error) {
            console.error(error.message);
        }
};


// returns a list of all parcel names
export const isSeasonValidPHFBModel = async () => {
  try{
      console.log("test");
      // fetch the data
      const res = await fetch(baseURL + `getParcelNamesPHFB`);
      if (!res.ok) {
        const message = 'Error';
        throw new Error(message);
      }
      
      const parcelNames = await res.json();

      return parcelNames;

      } catch(error) {
          console.error(error.message);
      }
};

// upload file function
export const importInitialMeasures = async (refFile, satFile, territory) => {
  const token = localStorage.getItem('token');
  try{
    const formData = new FormData();
    formData.append('refFile', refFile);
    formData.append('satFile', satFile);
    formData.append('territory', territory);
      // fetch the data
      const res = await fetch(baseURL + 'importInitialMeasures', {
          method: 'POST',
          headers: {
              // 'content-Type': 'application/csv',
              'Authorization': `Bearer ${token}`
          },
          body: formData
      });
      if (!res.ok) {
        const message = 'Error';
        throw new Error(message);
      }
      
      const result = await res.json();

      return result;

      } catch(error) {
          console.error(error.message);
      }
};

// observations upload function :  reprendre ici 
export const importNewMeasures = async (newMeasuresFile, territory) => {
  const token = localStorage.getItem('token');
  try{
    const formData = new FormData();
    formData.append('newMeasuresFile', newMeasuresFile);
    formData.append('territory', territory);
      // fetch the data
      const res = await fetch(baseURL + 'importNewMeasures', {
          method: 'POST',
          headers: {
              'Authorization': `Bearer ${token}`
          },
          body: formData
      });
      if (!res.ok) {
        const message = 'Error';
        throw new Error(message);
      }
      
      const result = await res.json();

      return result;

      } catch(error) {
          console.error(error.message);
      }
};

export const getTerritories = async () => {
  const token = localStorage.getItem('token');
  try{
      // fetch the data
      const res = await fetch(baseURL + 'getTerritories', {
          method: 'GET',
          headers: {
              'Authorization': `Bearer ${token}`
          },
      });
      if (!res.ok) {
        const message = 'Error';
        throw new Error(message);
      }
      
      const result = await res.json();

      return result;

      } catch(error) {
          console.error(error.message);
      }
};



