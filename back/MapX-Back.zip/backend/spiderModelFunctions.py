from datetime import datetime, timedelta
from db import *
import statsmodels.api as sm
import numpy as np
import pandas as pd
from flask import jsonify

deltaDate = timedelta(days=3)


#######################################################################################
#############################  SPIDER MODEL COMPUTATION FUNCTIONS  ####################
#######################################################################################

# returns a list of the seasons where PHFB measures have been done
def getSeasonsPHFB():
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.Annee FROM session_test GROUP BY Annee'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append(
            row[0] 
        )

    return result

# returns a list of parcel names where PHFB measures have been done
def getParcelNamesPHFB(territory):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT parcelles.nom_parcelle FROM parcelles WHERE territoire = "' + territory + '"'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'name': row[0]  
        }
        )

    return result



# get the valid parcels for spider model computation for the specified season 
# NB: a parcel is valid if there is at least one other parcel that has 3 measure dates in common with that parcel
def validParcelsSpiderModel(seasonYear):
    seasonParcels = getSeasonParcels(seasonYear)
    validParcels = []
    
    # iterate over all possible parcels combination
    for i in range(len(seasonParcels)):
        for j in range(i + 1, len(seasonParcels)):
            if threeCommonMeasures(seasonParcels[i], seasonParcels[j], seasonYear):
                # memorise parcels that match the condition
                if seasonParcels[i] not in validParcels:
                    validParcels.append(seasonParcels[i])
                if seasonParcels[j] not in validParcels:
                    validParcels.append(seasonParcels[j])
    return validParcels


# tells if the two specified parcels have at least 3 measures in common for the specified season (i.e done at the same date)
def threeCommonMeasures(parcelX, parcelY, seasonYear):
    measuresParcelX = getMeasuresParcelSeason(parcelX, seasonYear)
    measuresParcelY = getMeasuresParcelSeason(parcelY, seasonYear)

    i = 0
    nbCommonMeasures = 0
    commonMeasureDates = []
    # iterate over measures on parcelX
    while i < len(measuresParcelX):
        # check if there is a measure at the same date (+/- detalDate) on parcelY
        if measureAtSameDate(measuresParcelY, measuresParcelX[i]['date'], commonMeasureDates) != None:
            nbCommonMeasures = nbCommonMeasures + 1
            commonMeasureDates.append(measuresParcelX[i]['date'])
        if nbCommonMeasures >= 3:
            return True
        i = i + 1
    return False

# tells if the specified date is included in one of time frames defined by dates and deltaDate
def inTimeFrames(date, dates):
    for d in dates:
        if date <= d + deltaDate and date >= d - deltaDate:
            return True
    return False

# TODO: test/verify this function (vérifier notamment si inTimeFrames n'exclue pas plus de parcelles que ce qu'il faudrait)
# if the specified measureDate equals one of the provided measures' dates (+/- delta) returns the phfb value of the matching measure date
# the equality must take place outside of time frames where common measures have already been detected
def measureAtSameDate(measures, measureDate, commonMeasureDates):
    # verify that measureDate is not a date on which measure pairs have already been detected
    if not inTimeFrames(measureDate, commonMeasureDates):
        for measure in measures:
                # verify that measure['date'] is not a date on which measure pairs have already been detected
                if not inTimeFrames(measure['date'], commonMeasureDates):
                    if measure['date'] >= measureDate - deltaDate and measure['date'] <= measureDate + deltaDate:
                        return measure['phfb']
    return None

# get the measures of the specified parcel for the specified season
def getMeasuresParcelSeason(parcel, season_year):
    parcel = parcel.replace('"','') # delete potential '"" character in parcel name
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.id, session_test.Parcelle, session_test.formatted_date, session_test.PHFB FROM session_test WHERE session_test.Annee = ' + season_year + ' AND session_test.Parcelle = ' + '"' + parcel + '"'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'parcel_name': row[1], 
            'date': row[2],
            'phfb': row[3]
        })
    return result

def getMeasuresSeason(season_year):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.id, session_test.Parcelle, session_test.formatted_date FROM session_test WHERE session_test.Annee = ' + season_year
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'parcel_name': row[1], 
            'date': row[2]
        })
    return result

# get the number of parcels involved the specified season
def getNumberParcelsSeason(season_year):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'select count(*) from (select session_test.parcelle from session_test where annee = ' + season_year + ' group by session_test.parcelle) as nb_parcels'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            row[0]
        })
    return result

# get the list of the parcels involved the specified season
def getSeasonParcels(season_year):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.parcelle FROM session_test WHERE session_test.Annee = ' + season_year + ' GROUP BY session_test.parcelle'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append(
            row[0]
        )
    return result

# returns the ASI coefficients between the reference parcel and each one of the valid satellite parcels for the specified seasons
def getSpiderCoeffs(satFile, refFile, territory):
    coeffs = []

    # get lists of satellite parcels and reference parcels
    refParcels = getParcelsNames(refFile)
    satParcels = getParcelsNames(satFile)

    # iterate over all satellite parcels
    for satParcel in satParcels:
        # iterate over all reference parcels
        for refParcel in refParcels:
            # get spider coeffs between current ref parcel and satellite parcel
            getSpiderCoeffsParcel(satParcel, refParcel, satFile, refFile, territory)

    return coeffs

# process the spider coefficients between the given satellite parcel and reference parcel
def getSpiderCoeffsParcel(satParcel, refParcel, satFile, refFile, territory):
    # get all measures, along with their dates, of the given satellite parcel 
    [satMeasures, dates, lat, long] = getMeasuresParcel(satParcel, satFile) # LIGNE QUI PREND DU TEMPS A PRIORI
    # [satMeasures, dates] = getMeasuresParcel(satParcel) # LIGNE QUI PREND DU TEMPS A PRIORI

    ## Linear regression ##
        # -> calculate a and b parameters of the equation: Y = aX + b (here Y = 0.5X + 1) - X: refMeasures, Y: satMeasures

    # get all measures of the given reference parcel at the same dates than the satellite parcel measures
    refMeasures = getSimulatedMeasuresRefParcel(refParcel, refFile, dates) # LIGNE QUI PREND DU TEMPS A PRIORI
    # refMeasures = getSimulatedMeasuresRefParcel(refParcel, dates) # LIGNE QUI PREND DU TEMPS A PRIORI

    # add a constant (b constant) to the predictor variable (X)
    refMeasures = sm.add_constant(refMeasures)

    # perform regression
    model = sm.OLS(satMeasures, refMeasures).fit()

    # save the coeffs for the couple reference/satellite parcels
    saveCoeff(model.params[1], satParcel, refParcel, territory, lat, long)
    return '1'

# save asi coefficient for specified reference and satellite parcels
def saveCoeff(coeff, satParcel, refParcel, territory, lat, long):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # TODO : delete existing coeffs at the beginning of the whole process of coeffs processing (for all parcels)
    # cursor.execute('DELETE FROM coefficients')
    query = 'INSERT INTO coefficients (parcel, coeff, refParcel, territoire, latitude, longitude) VALUES (%s, %s, %s, %s, %s, %s)'
    values = (satParcel, float(coeff), refParcel, territory, lat, long)
    cursor.execute(query, values)
    db_phfb.commit()
    cursor.close()

# get all the measures of a specified parcel along with their corresponding dates
def getMeasuresParcel(pParcel, pFile):
    measures = []
    dates = []
    longitude = ''
    latitude = ''
    # skip hearder line
    line = pFile.readline() 
    # loop over all lines
    while True:
        line = pFile.readline()
        if not line:
            break
        line = line.decode('utf-8')
        attributes = line.split(';')
        # get parcel's attributes
        parcel = attributes[0]
        date = attributes[1]

        phfb = attributes[5]
        # check if current parcel is the specified parcel
        if pParcel == parcel:
            if latitude == '' and longitude == '':
                latitude = attributes[3]
                longitude = attributes[4]
            measures.append(float(phfb.replace(',','.'))) # reprendre ici : erreur lors de la conversion en float
            dates.append(date)
            
    # reset file's pointer to beginning of the file
    pFile.seek(0)
    print("result teeeeeeeeeeeest: ", [measures, dates])
    return [measures, dates, latitude, longitude]


# get all the simulated measures of a specified reference parcel at the specified dates
def getSimulatedMeasuresRefParcel(pParcel, pFile, pDates):
    measures = []
    # skip hearder line
    line = pFile.readline() 
    # loop over all lines
    while True:
        line = pFile.readline()
        if not line:
            break
        line = line.decode('utf-8')
        attributes = line.split(';')
        # get parcel's attributes
        parcel = attributes[0]
        date = attributes[1]
        phfb_bilan_hydrique = attributes[6]
        # check if current parcel is the specified reference parcel
        if parcel == pParcel:
            if date in pDates:
                measures.append(float(phfb_bilan_hydrique.replace(',','.')))
    # reset file's pointer to beginning of the file
    pFile.seek(0)
    return measures

# get all the parcels' names of a measures file and return it in the form of a list
# E: file (can be a file a references parcels or satellite parcels)
def getParcelsNames(file):
    parcels = []
    # skip hearder line
    line = file.readline() 
    # loop over all lines
    while True:
        line = file.readline()
        if not line:
            break
        line = line.decode('utf-8')
        attributes = line.split(';')
        # get parcel's name
        parcel = attributes[0]
        # check if current parcel is already memorised in refParcels list
        if parcel not in parcels:
            parcels.append(parcel)
    # reset file's pointer to beginning of the file
    file.seek(0)
    return parcels



def linearRegressionExample():
    # calculate a and b parameters of the equation: Y = aX + b (here Y = 0.5X + 1)
    X = [1, 4, 5]  # Predictor variable
    Y = [1.5, 3, 3.5]  # Target variable
    print('X: ', X)
    print('Y: ', Y)

    # Add a constant to the predictor variable (b constant)
    X = sm.add_constant(X)

    # Perform OLS regression
    model = sm.OLS(Y, X).fit()

    # Print a summary of the regression results
    print(model.summary())
    print('b constant  ', model.params[0])
    print('a coeff ', model.params[1])
    
    return '1'


# compute the valid satellite parcels along with their usable measures for spider model computation
# for the specified reference parcel and the specified season
def computeValidSatelliteParcels(season, candidateSatelliteParcels, refParcel, commonMeasureValues):
    # get measures of the reference parcels
    refParcelMeasures = getMeasuresParcelSeason(refParcel, season)

    # compute valid parcels for model computation
    for parcel in candidateSatelliteParcels:
        # get measures of the current parcel
        parcelMeasures = getMeasuresParcelSeason(parcel, season)
        computeSatelliteParcelMeasures(season, parcel, refParcel, parcelMeasures, refParcelMeasures, commonMeasureValues)

# if the specified parcel is valid for spider model computation, returns its usable measures for model computation
# else returns none
def computeSatelliteParcelMeasures(season, parcel, refParcel, parcelMeasures, refParcelMeasures, commonMeasureValues):
    # iterate over parcel's measures
    commonMeasureDates = []
    for parcelMeasure in parcelMeasures:
        # if there is a measure on the ref parcel at the same date than the current measure
        refParcelMeasure = measureAtSameDate(refParcelMeasures, parcelMeasure['date'], commonMeasureDates)
        if refParcelMeasure != None:
            # memorise the measure's date
            commonMeasureDates.append(parcelMeasure['date'])
            # memorise measure values of both parcels (ref parcel + other parcel)
            commonMeasureValues.append({'season': season, 'parcel': parcel, 'satelliteParcelMeasure': parcelMeasure['phfb'], 'referenceParcelMeasure': refParcelMeasure})
    return None

# get all measures for the specified parcels for the specified season
def getMeasuresParcels(season, parcels):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()

    # compute request's parcels list
    parcelsList = '('
    i = 0
    nbParcels = len(parcels)
    while i < nbParcels:
        if i < nbParcels - 1:
            parcelsList = parcelsList + "'" + parcels[i] + "'" + ', '
        else:
            parcelsList = parcelsList + "'" + parcels[i] + "'" + ')'
        i += 1

    # make request
    cursor.execute(
        'SELECT session_test.id, session_test.Parcelle, session_test.formatted_date, session_test.PHFB FROM session_test WHERE session_test.Parcelle IN ' + parcelsList + ' AND session_test.Annee = ' + season
    )
    data = cursor.fetchall()
    cursor.close()

    # convert result's data 
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'parcel': row[1], 
            'date': row[2],
            'phfb': row[3]
        })
    
    return result

#######################################################################################
#############################  ESTIMATION COMPUTATION FUNCTIONS  ######################
#######################################################################################


# get the reference parcel of the calculated spider model
# if no spider model has been calculated, returns None
def getRefParcel():
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    cursor.execute('SELECT coefficients.refParcel FROM coefficients LIMIT 1')
    data = cursor.fetchall()
    cursor.close()
    for row in data:
        return row[0]
    
# get the coefficients for a specified territory
def getCoefficients(territory):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()

    cursor.execute('SELECT coefficients.parcel, coefficients.coeff, coefficients.refParcel, coefficients.latitude, coefficients.longitude FROM coefficients WHERE coefficients.territoire = "' + territory + '"')
    data = cursor.fetchall()

    cursor.close()

    result = []
    for row in data:
        result.append({
            'satelliteParcel': row[0],
            'coeff': row[1],
            'referenceParcel': row[2],
            'latitude': row[3],
            'longitude': row[4]
        }) 
    return result



    
# compute estimated PHFB values from a new ref measure for all parcels associated to a reference parcel 
def computeEstimationFromRefParcel(refParcel, refParcelMeasure, refParcelMeasureDate, refParcelMeasureYear):
    # get satellite parcels and coeffs
    coeffs = getCoefficients()
    # iterate over satellite parcels
    for coeff in coeffs:
        # compute estimated PHFB for current parcel
        estimatedPHFB = str(float(refParcelMeasure) * float(coeff['coeff']))
        # compute mean satellite parcel coordinates
        meanCoord = getParcelCoordinates(coeff['parcel'])
        meanLatitude = str(meanCoord['meanLatitude'])
        meanLongitude = str(meanCoord['meanLongitude'])
        # save estimated values
        savePHFBMeasure(coeff['parcel'], refParcelMeasureDate, refParcelMeasureYear, meanLatitude, meanLongitude, estimatedPHFB, 'estimation')

def savePHFBMeasure(parcel, date, year, latitude, longitude, value, measureType):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # insert new row
    query = 'INSERT INTO session_test (Parcelle, Date, Annee, Latitude, Longitude, PHFB, type_mesure) VALUES (' + "'" + parcel + "'" + ', ' + "'" + date + "'" + ', ' + "'" + year + "'" + ', ' + "'" + latitude + "'" + ', ' + "'" + longitude + "'" + ', ' + "'" + value + "'" + ', ' + "'" + measureType + "'" + ')'
    cursor.execute(query)
    db_phfb.commit()
    cursor.close()

# get the mean latitude and longitude of the measures done on a specified parcel
def getParcelCoordinates(parcel, territory):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # query = 'SELECT avg(CAST(replace(mesures_satellites.Latitude,",", ".") as decimal(10,8))), avg(cast(replace(mesures_satellites.Longitude, ",",".") as decimal(10,8))) FROM `mesures_satellites` where parcelle = ' + '"' + parcel + '"'
    query = 'SELECT mesures_satellites.Latitude, mesures_satellites.Longitude FROM `mesures_satellites` where parcelle = ' + '"' + parcel + '" AND territoire = "' + territory + '" LIMIT 1'
    cursor.execute(query)
    data = cursor.fetchall()

    cursor.close()

    for row in data:
        return {
            'meanLatitude': row[0],
            'meanLongitude': row[1],
        }
        

#######################################################################################
#############################  GENERAL DB REQUEST FUNCTIONS  ##########################
#######################################################################################