from flask import request, jsonify
from utils import *
from db import *
from __main__ import app
from datetime import datetime
from flask_jwt_extended import jwt_required, get_jwt_identity
import uuid

# Mapper les noms de colonnes à renommer
column_mapping = {
    'id_parcelle': 'id',
    'nom_parcelle': 'name',
    'date_creation': 'createdAt',
    'date_maj': 'updatedAt',
    'id_proprietaire': 'ownerId',
    'latitude': 'latitude',
    'longitude': 'longitude',
}


@app.route('/parcels')
@jwt_required()
def getAuthorizedParcels():
    # Récupère l'id de la personne authentifié grâce à son token
    identity = get_jwt_identity()
    if not identity:
        return jsonify({'message': 'Missing Authorization Header'}), 401

    checkConnection(db_icapex)
    cursor = db_icapex.cursor()

    # Check si l'user est le propriétaire de la parcelle
    # Si l'user à accès à la parcelle partagée, il peut la voir
    select_query = ('SELECT * FROM parcelle '
                   'WHERE id_parcelle IN (SELECT id_parcelle FROM utilisateur_parcelle WHERE id_utilisateur = %s)'
                    )
    cursor.execute(select_query, (identity,))
    parcels = cursor.fetchall()

    if parcels is None :
        return jsonify({})

    # Récupérer les noms des colonnes
    column_names = [desc[0] for desc in cursor.description]

    # Créer une liste de dictionnaires associant les noms des colonnes aux valeurs
    result = [dict(zip(column_names, parcel)) for parcel in parcels]

    # # Renommer les clés du dictionnaire en utilisant le mapping
    for parcel in result:
        for old_key, new_key in column_mapping.items():
            if old_key in parcel :
                parcel[new_key] = parcel.pop(old_key)
                
    cursor.close()

    return jsonify(result)


@app.route('/parcels/<string:id>')
@jwt_required()
def getAuthorizedParcel(id):
    # Récupère l'id de la personne authentifié grâce à son token
    identity = get_jwt_identity()
    if not identity:
        return jsonify({'message': 'Missing Authorization Header'}), 401

    checkConnection(db_icapex)
    cursor = db_icapex.cursor()

    # Check si l'user est le propriétaire de la parcelle
    # Si l'user à accès à la parcelle partagée de cette id, il peut la voir
    # cursor.execute('SELECT * FROM parcelle '
    #                'WHERE id_parcelle = %s AND id_proprietaire = %s '
    #                'OR %s IN (SELECT id_utilisateur FROM utilisateur_parcelle WHERE id_parcelle = %s)',
    select_query = ('SELECT * FROM parcelle '
                   'WHERE id_parcelle = %s '
                   'AND id_parcelle IN (SELECT id_parcelle FROM utilisateur_parcelle WHERE id_utilisateur = %s)'
                    )
    cursor.execute(select_query, (id, identity))
    parcel = cursor.fetchone()

    if parcel is None :
        return jsonify({})

    # Récupérer les noms des colonnes
    column_names = [desc[0] for desc in cursor.description]

    # Créer une liste de dictionnaires associant les noms des colonnes aux valeurs
    result = [dict(zip(column_names, parcel))]
    parcel = result[0]

    # Renommer les clés du dictionnaire en utilisant le mapping
    for old_key, new_key in column_mapping.items():
        if old_key in parcel :
            parcel[new_key] = parcel.pop(old_key)

    cursor.close()

    return jsonify(parcel)


@app.route('/parcels', methods=['POST'])
@jwt_required()
def addParcel():
    # Récupère l'id de la personne authentifié grâce à son token
    identity = get_jwt_identity()
    if not identity:
        return jsonify({'message': 'Missing Authorization Header'}), 401

    checkConnection(db_icapex)
    cursor = db_icapex.cursor()

    data = request.get_json()
    # Vérifier que les données sont présentes et valides
    if not data:
        return jsonify({'message': 'No data provided'}), 400
    if not 'name' in data:
        return jsonify({'message': 'Missing name'}), 400

    # Generate a new UUID
    uuid_generated = uuid.uuid4().hex

    insert_data = {
        'id_parcelle': uuid_generated,
        'nom_parcelle': data['name'],
        'id_proprietaire': identity,
    }

    insert_query = ('INSERT INTO parcelle (' + ', '.join(f'{key}' for key in insert_data.keys()) + ') '
                    'VALUES (' + ', '.join(f'%s' for key in insert_data.keys()) + ')'
                    )
    insert_values = list(insert_data.values())
    cursor.execute(insert_query, insert_values)

    # insert also in utilisateur_parcelle table
    insert_query = ('INSERT INTO utilisateur_parcelle (id_utilisateur, id_parcelle) VALUES (%s, %s)')
    insert_values = (identity, uuid_generated)
    cursor.execute(insert_query, insert_values)

    db_icapex.commit()
    cursor.close()

    return jsonify({'message': 'Parcel added', 'id': uuid_generated}), 201