from datetime import datetime

# change a date to the format dd/mm/yyyy
def changeDateFormatDayMonthYear(date):
    day = date.day
    month = date.month
    year = date.year
    if day < 10:
        day = '0' + str(day)
    if month < 10:
        month = '0' + str(month)

    return str(day) + '/' + str(month) + '/' + str(year)