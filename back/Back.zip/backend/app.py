import sys
from flask import Flask, jsonify, request
from flask_cors import CORS
from datetime import datetime
from db import *
from spiderModelFunctions import *
from utils import *
from dotenv import load_dotenv
from flask_jwt_extended import JWTManager, jwt_required, get_jwt_identity

import csv


load_dotenv()

'initialize flask app'
app = Flask(__name__)
app.config['JWT_SECRET_KEY'] = 'hul_r22okle'
jwt = JWTManager(app)
CORS(app)

@app.route('/', methods=['GET'])
def hello_world():
    return jsonify('Hello, aurelien!')


@app.route('/test')
def main():
    checkConnection(db_icapex)
    cursor = db_icapex.cursor()
    cursor.execute('SELECT * FROM parcelles')
    cursor.fetchall()
    number_of_rows = cursor.rowcount
    app.logger.info(number_of_rows)
    cursor.close()
    return jsonify('nombre de parcelles : ' + str(number_of_rows))


import mobile.sessions
import mobile.parcels
import user

#######################################################################################
#############################  IMPORT FILE FUNCTIONS  #################################
#######################################################################################

@app.route('/uploadCSVFile', methods=['POST'])
@jwt_required()
def upload():
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    if request.method == 'POST':
        # Get the uploaded file
        csv_file = request.files['./session_test.csv']
        
        # Read the CSV file and import data into MySQL table
        csv_data = csv.reader(csv_file)
        # next(csv_data)  # Skip header if exists
        for row in csv_data:
            cursor.execute("INSERT INTO session_test (id,Parcelle,Date,Cepage,Annee,Latitude,Longitude,AGI,nb_apex0,nb_apex0_5,nb_apex1,PHFB,week,total_apex,taux_apex0,taux_apex0_5,taux_apex1,PHFB_classes,Pred_IFV,type_mesure) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)", row)
        
        cursor.commit()
        
        return 'CSV file successfully uploaded to MySQL database!'


#######################################################################################
#############################  MAP VISUALISATION FUNCTIONS  ###########################
#######################################################################################

# get latitude and longitude of a specified parcel
@app.route('/getLatLongParcel', methods=['GET'])
@jwt_required()
def getLatLongParcel():
    #get parameters
    parcelName = request.args.get('parcelName')
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.Latitude, session_test.Longitude FROM session_test WHERE session_test.Parcelle = ' + '"' + parcelName + '" LIMIT 1'
    )
    data = cursor.fetchall()
    cursor.close()
    result = []
    for row in data:
        result.append({
            'latitude':row[0],
            'longitude':row[1],
        })
    return jsonify(result)


# get latest PHFB measure's date
@app.route('/getLatestPHFBMeasureDate', methods=['GET'])
@jwt_required()
def getLatestPHFBMeasureDate():
    #get parameters
    territory = request.args.get('territory')
    print('request : ', 'SELECT date FROM mesures_references WHERE mesures_references.territoire = "' + territory + '" order by formatted_date DESC LIMIT 1')
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # cursor.execute('SELECT date FROM mesures_references LIMIT 1')
    cursor.execute('SELECT date FROM mesures_references WHERE mesures_references.territoire = "' + territory + '" order by formatted_date DESC LIMIT 1')
    data = cursor.fetchall()
    cursor.close()
    result = []
    print('data: ', data)
    for row in data:
        result.append(row[0])
    return jsonify(result)

# get parcel IDs of the user
@app.route('/getUserParcelIDs', methods=['GET'])
@jwt_required()
def getUserParcelIDs():
    # get JWT token identity
    # current_user = get_jwt_identity()
    # Todo: use user's id (or email/identity) got from get_jwt_identity to make the request to avoid cheating on user's identity
    
    #get parameters
    checkConnection(db_admin)
    cursor = db_admin.cursor()
    # todo: get user ID and use it in the request
    cursor.execute('SELECT utilisateur_parcelle.id_parcelle_icapex FROM utilisateur_parcelle WHERE utilisateur_parcelle.id_utilisateur = "cd3ac534-a9f8-4879-9167-5411b981202d" ' +
                   'AND utilisateur_parcelle.id_parcelle_icapex IS NOT NULL')
    data = cursor.fetchall()
    cursor.close()
    parcelIDs = []
    for id in data:
        parcelIDs.append(id[0])
    return parcelIDs

'create a route in the flask app to retrieve data from the DB and return it as JSON'
# get ICAPEX measures between specified startDate and endDate
@app.route('/getICAPEXMeasures', methods=['GET'])
@jwt_required()
def getICAPEXMeasures():
    # get parcel IDs from other python function and use IDs list to make measures request
    parcelIDs = getUserParcelIDs()
    format_strings = ','.join(['%s'] * len(parcelIDs))

    # get JWT token identity
    current_user = get_jwt_identity()
    # Todo: use user's id (or email/identity) got from get_jwt_identity to make the request to avoid cheating on user's identity
    # current_user = get_jwt_identity()
    

    #get parameters
    startDate = request.args.get('startDate')
    endDate = request.args.get('endDate')
    checkConnection(db_icapex)
    cursor = db_icapex.cursor()
    cursor.execute(
        'SELECT observation.id_session, AVG(observation.apex_value)/2 as apex_value, AVG(observation.latitude) as latitude, AVG(observation.longitude) as longitude, ' +
            ' session.date_session_test, parcelle.nom_parcelle, parcelle.id_parcelle FROM observation ' + 
                'LEFT JOIN session ON observation.id_session = session.id_session LEFT JOIN ' + 
                    'Parcelle ON session.id_parcelle = Parcelle.id_parcelle ' + 
                        'WHERE session.date_session_test >= ' + '"' + startDate + '"' + ' AND session.date_session_test <= ' + '"' + endDate + '"' + '  AND session.id_parcelle IN (%s)' % format_strings + ' GROUP BY observation.id_session', tuple(parcelIDs) 
    )
    data = cursor.fetchall()
    cursor.close()
    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'date': row[4],
            'parcel_name':row[5],
            'apex_value': row[1],
            'measure_type':'mesure',
            'type':'IC-APEX',
            'date':row[4],
            'reliability':'high',
            'latitude':row[2],
            'longitude':row[3],
        })
    return jsonify(result)


# get PHFB measures between specified startDate and endDate
@app.route('/getPHFBMeasures', methods=['GET'])
@jwt_required()
def getPHFBMeasures():
    # get parameters
    startDate = request.args.get('startDate')
    endDate = request.args.get('endDate')
    territory = request.args.get('territory')
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT mesures_references.id, mesures_references.Date, mesures_references.Parcelle, mesures_references.PHFB_bilan_hydrique, mesures_references.Latitude, mesures_references.Longitude, "mesure" as type_mesure FROM mesures_references ' 
        + 'WHERE mesures_references.formatted_date >= ' + '"' + startDate + '"' + ' AND mesures_references.formatted_date <= ' + '"' + endDate + '"'
        + ' and territoire = "' + territory + '"'
        + ' UNION '
        + 'SELECT mesures_satellites.id, mesures_satellites.Date, mesures_satellites.Parcelle, AVG(mesures_satellites.PHFB) as avg_phfb, mesures_satellites.Latitude, mesures_satellites.Longitude, "estimation" as type_mesure FROM mesures_satellites ' 
        + ' WHERE mesures_satellites.type_mesure = "estimation" AND mesures_satellites.formatted_date >= ' + '"' + startDate + '"' + ' AND mesures_satellites.formatted_date <= ' + '"' + endDate + '"' + ' AND territoire = "' + territory + '" GROUP BY mesures_satellites.parcelle, mesures_satellites.territoire'
    )
    data = cursor.fetchall()
    cursor.close()
    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'date': row[1],
            'parcel_name':row[2],
            'phfb_value': row[3],
            'measure_type':row[6],
            'type':'PHFB',
            'reliability': 'medium' if row[6] == 'estimation' else 'high',
            'latitude':row[4],
            'longitude':row[5],
        })
    print('result: ', result)
    return jsonify(result)

#######################################################################################
#############################  PARCEL VISUALISATION FUNCTIONS  ########################
#######################################################################################

# get all seasons (for PHFB measures) of a specified parcel
@app.route('/getSeasonsPHFBParcel', methods=['GET'])
def getSeasonsPHFBParcel():
    # get parameters
    parcel = request.args.get('parcel')
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT session_test.Annee FROM session_test WHERE session_test.Parcelle = ' + '"' + parcel + '"' + 'GROUP BY Annee', multi = True
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    # for row in data:
    #     result.append(row[0])
    # return result
    return 'test'


# get all the measures (PHFB and ICAPEX) of a specified parcel
@app.route('/getParcelMeasures', methods=['GET'])
def getParcelMeasures():
    # get parameters
    parcel = request.args.get('parcel')

    # get measures 
    parcelPHFBMeasures = getParcelPHFBMeasures(parcel)
    # parcelICAPEXMeasures = getParcelICAPEXMeasures(parcel)

    # merge PHFB and ICAPEX measures
    # parcelMeasures = parcelPHFBMeasures + parcelICAPEXMeasures
    parcelMeasures = parcelPHFBMeasures
    
    return jsonify(parcelMeasures)

# get all the PHFB measures of a specific parcel
def getParcelPHFBMeasures(parcel):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute(
        'SELECT mesures_references.id, mesures_references.Date, mesures_references.Parcelle, mesures_references.PHFB_bilan_hydrique, mesures_references.Latitude, mesures_references.Longitude, "mesure" as measure_type, mesures_references.Annee FROM mesures_references ' 
            + 'WHERE mesures_references.Parcelle = ' + '"' + parcel + '"'
            + ' UNION '
            + 'SELECT mesures_satellites.id, mesures_satellites.Date, mesures_satellites.Parcelle, mesures_satellites.PHFB, mesures_satellites.Latitude, mesures_satellites.Longitude, mesures_satellites.type_mesure, mesures_satellites.Annee FROM mesures_satellites ' 
            + 'WHERE mesures_satellites.Parcelle = ' + '"' + parcel + '"'
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'date': row[1],
            'parcel_name':row[2],
            'measure_value': row[3],
            'measure_type':row[6],
            'type':'PHFB',
            'unit':'MPa',
            'reliability': 'medium' if row[6] == 'estimation' else 'high',
            'latitude':row[4],
            'longitude':row[5],
            'annee':row[7]
        })
    return result

def getParcelICAPEXMeasures(parcel):
    checkConnection(db_icapex)
    cursor = db_icapex.cursor()
    # make request
    cursor.execute(
        'SELECT observation.id_session, AVG(observation.apex_value)/2 as apex_value, AVG(observation.latitude) as latitude, AVG(observation.longitude) as longitude, ' +
            ' session.date_session_test, parcelle.nom_parcelle FROM observation ' + 
                'LEFT JOIN session ON observation.id_session = session.id_session LEFT JOIN ' + 
                    'Parcelle ON session.id_parcelle = Parcelle.id_parcelle ' + 
                        'WHERE Parcelle.nom_parcelle = ' + '"' + parcel + '"' + ' GROUP BY observation.id_session'
    )
    data = cursor.fetchall()
    cursor.close()
    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'date': row[4],
            'parcel_name':row[5],
            'measure_value': row[1],
            'measure_type':'mesure',
            'type':'IC-APEX',
            'unit':'-',
            'date':row[4],
            'reliability':'high',
            'latitude':row[2],
            'longitude':row[3],
        })
    return result

# get all parcel names (from PHFB database)
@app.route('/getParcelNames', methods=['GET'])
def getParcelNames():
    territory = request.args.get('territory')
    parcelNamesPHFB = getParcelNamesPHFB(territory)
    return jsonify(parcelNamesPHFB)

def getParcelNamesICAPEX():
    checkConnection(db_icapex)
    cursor = db_icapex.cursor()
    # make request
    cursor.execute(
        'SELECT  ' +
            ' parcelle.id_parcelle, parcelle.nom_parcelle FROM Parcelles '
    )
    data = cursor.fetchall()
    cursor.close()

    # Convert data to list of key/value pairs
    result = []
    for row in data:
        result.append({
            'id': row[0],
            'name': row[1],
        })
    return result



#######################################################################################
#############################  SPIDER MODEL FUNCTIONS  ################################
#######################################################################################

# TODO: verify this function, especially when checking time frames (to know if current date hasn't been yet checked)
@app.route('/getValidSeasonsSpiderModel', methods=['GET'])
# returns a list of the seasons valid for spider model
def getValidSeasonsSpiderModel():
    validSeasons = []
    validParcels = {}
    # get all seasons for phfb measures
    phfbSeasons = getSeasonsPHFB()
    # check validity of each season
    for season in phfbSeasons:
        # get valid parcels for current season
        validParcels[season] = validParcelsSpiderModel(season)
        # if there is more than one valid parcel the season is valid
        if len(validParcels) > 0:
            validSeasons.append(season)

    return jsonify([validSeasons, validParcels])

@app.route('/computeSpiderCoefficients', methods=['GET'])
# compute and returns the ASI coefficients between the reference parcel and each one of the satellite parcels for the specified seasons
def computeSpiderCoefficients():
    # get parameters
    # seasons = request.args.get('seasons').split(',')
    # get seasons with a request : Select distinct annee from satteliteMeasures 
    candidateSatelliteParcels = request.args.get('candidateSatelliteParcels').split(',')
    refParcel = request.args.get('refParcel')
    
    # get asi coeffs
    coeffs = getSpiderCoefficients(seasons, candidateSatelliteParcels, refParcel)

    # save coeffs on DB
    saveCoeffs(coeffs, refParcel)

    return jsonify(coeffs)

# compute and returns the ASI coefficients between the reference parcel and each one of the satellite parcels for the specified seasons
def computeSpiderCoeffs(satFile, refFile, territory):    
    # get asi coeffs
    coeffs = getSpiderCoeffs(satFile, refFile, territory)

    # save coeffs on DB
    # saveCoeffs(coeffs, refParcel)

    return jsonify(coeffs)

# save asi coefficients on DB
def saveCoeffs(coeffs, refParcel):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()

    # delete existing coeffs
    cursor.execute('DELETE FROM coefficients')

    # iterate over coefficients to save
    for coeff in coeffs:
        # delete potential pre-existing coeffs for current parcel and refParcel - TODO: make this isn't relevant to do it and delete it
        # cursor.execute('DELETE FROM coefficients WHERE coefficients.parcel = ' + '"' + coeff['parcel'] + '"' + ' and coefficients.refParcel = ' + '"' + refParcel + '"')
        
        # insert coeff values
        query = 'INSERT INTO coefficients (parcel, coeff, refParcel) VALUES (%s, %s, %s)'
        values = (coeff['parcel'], float(coeff['coeff']), refParcel)
        cursor.execute(query, values)
    db_phfb.commit()
    cursor.close()

@app.route('/getCoeffs', methods=['GET'])
# returns the spider coefficients stored in the DB
def getCoeffs():
    return getCoefficients()


@app.route('/deleteSpiderModel', methods=['GET'])
# delete coeffs from the coefficient table
def deleteSpiderModel():
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute('DELETE FROM coefficients')
    # data = cursor.fetchall()
    db_phfb.commit()
    cursor.close()
    return jsonify(1)


@app.route('/testingMethod', methods=['GET'])
def testingMethod():
    coord = getParcelCoordinates('Pilotype gr 17')
    return coord

# get parcel names from PHFB DB
@app.route('/getParcelsPHFB', methods=['GET'])
def getParcelsPHFB():
    return jsonify(getParcelNamesPHFB())


@app.route('/getRefParcelSpiderModel', methods=['GET'])
def getRefParcelSpiderModel():
    refParcel = getRefParcel()
    return jsonify(getRefParcel())


# import satellite parcel measures into DB
@app.route('/importInitialMeasures', methods=['POST'])
def importInitialMeasures():
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()

    # get files
    satFile = request.files['satFile']
    refFile = request.files['refFile']

    # get territory name 
    territory = request.form.get('territory')

    # delete initial measures for territory
    cursor.execute('DELETE FROM mesures_references WHERE territoire = ' + '"' + territory + '"')
    cursor.execute('DELETE FROM mesures_satellites WHERE territoire = ' + '"' + territory + '"')

    # delete parcels for territory
    cursor.execute('DELETE FROM parcelles where territoire = ' + '"' + territory + '"')

    # delete coefficients for territory
    cursor.execute('DELETE FROM coefficients WHERE parcel IN (SELECT nom_parcelle FROM parcelles WHERE parcelles.territoire = "' + territory + '")')

    # delete territory 
    cursor.execute('DELETE FROM territoires WHERE nom_territoire = ' + '"' + territory + '"')

    # add territory
    addTerritory(cursor, territory)

    # import measures
    importFile(satFile, 'satellite', cursor, territory)
    importFile(refFile, 'reference', cursor, territory)

    # process spider model
    computeSpiderCoeffs(satFile, refFile, territory)

    ## estimate satellite parcels phfb ##
    # get spider model coefficients
    coeffs = getCoefficients(territory)

    # estimate satellite parcels phfb for all refernce parcels phfb
    estimateSatelliteParcelsFromAllRefParcel(refFile, territory, coeffs, cursor)

    db_phfb.commit()
    cursor.close()
    return '1'

def importFile(file, parcels_type, cursor, territory_name):
    line = file.readline() # skip hearder line
    values = []
    # loop over all lines
    while True:
        line = file.readline()
        if not line:
            break
        line = line.decode('utf-8')
        attributes = line.split(';')
        # get attributes
        parcel = attributes[0]
        date = attributes[1]
        annee = attributes[2]
        latitude = attributes[3]
        longitude = attributes[4]
        phfb = attributes[5]
        # insert parcel 
        addParcel(parcel, cursor, territory_name)
        # insert measures
        if parcels_type == 'reference':
            phfb_bilan_hydrique = attributes[6]
            values.append((parcel, territory_name, date, annee, latitude, longitude, phfb, phfb_bilan_hydrique))
        else:
            values.append((parcel, territory_name, date, annee, latitude, longitude, phfb, 'mesure'))
    values_string = ', '.join(str(t) for t in values)
    if parcels_type == 'reference':
        query = f'INSERT INTO mesures_references (Parcelle, Territoire, Date, Annee, Latitude, Longitude, PHFB, PHFB_bilan_hydrique) VALUES {values_string}'
    else:
        query = f'INSERT INTO mesures_satellites (Parcelle, Territoire, Date, Annee, Latitude, Longitude, PHFB, type_mesure) VALUES {values_string}'
    cursor.execute(query)
    
    # reset file's pointer to beginning of the file
    file.seek(0)
    return '1'

# add specified parcel into the DB if the parcel doesn't exist yet 
def addParcel(parcel_name, cursor, territory_name):
    # check if parcel already exists
    cursor.execute('SELECT * FROM parcelles where nom_parcelle = ' + '"' + parcel_name + '"' + 'AND territoire = ' + '"' + territory_name + '"')
    data = cursor.fetchall()

    # if parcel doesn't exist yet create it
    if (len(data) == 0):
        # reprendre ici 1: ajouter le territoire comme clé étrangère de la parcelle (récupérer nom territoire en paramètre de la fonction)
        cursor.execute('INSERT INTO parcelles (nom_parcelle, territoire) VALUES ("' + parcel_name + '", "' + territory_name + '")')
    return '1'

# add specified territory into the DB 
def addTerritory(cursor, territory_name):
    cursor.execute('INSERT INTO territoires (nom_territoire) VALUES ("' + territory_name + '")')
    return '1'

# import reference parcel measures into DB
@app.route('/importNewMeasures', methods=['POST'])
def importNewMeasures():
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()

    # get measures' file
    newMeasuresFile = request.files['newMeasuresFile']

    # get territory name 
    territory = request.form.get('territory')

    # get spider model coefficients
    coeffs = getCoefficients(territory)

    # get new measures' year
    year = getYearNewMeasuresFile(newMeasuresFile)

    # delete preexisting satellite estimations for new measures' year 
    deleteSatelliteEstimationsYear(year, territory)

    # delete preexisting reference measures for new measures' year
    deleteReferenceMeasuresYear(year, territory)

    line = newMeasuresFile.readline() # skip hearder line
    # loop over file lines
    insert_estimation_values = []
    while True:
        line = newMeasuresFile.readline()
        if not line:
            break
        line = line.decode('utf-8')
        attributes = line.split(';')
        # get attributes
        parcel = attributes[0]
        date = attributes[1]
        annee = attributes[2]
        latitude = attributes[3]
        longitude = attributes[4]
        phfb = attributes[5]
        phfb_bilan_hydrique = attributes[6]

        # record new reference parcel measures in DB 
        query = 'INSERT INTO mesures_references (Parcelle, Territoire, Date, Annee, Latitude, Longitude, PHFB, PHFB_bilan_hydrique) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)'
        values = (parcel, territory, date, annee, latitude, longitude, phfb, phfb_bilan_hydrique)
        cursor.execute(query, values)

        # estimate satellite parcel measures
        insert_estimation_values = insert_estimation_values + (estimateSatelliteParcelsFromRefParcel(parcel, territory, phfb_bilan_hydrique, date, annee, coeffs))

    # reset file's pointer to beginning of the file
    newMeasuresFile.seek(0) 

    # record satellite estimations
    insert_estimation_values_string = ', '.join(str(t) for t in insert_estimation_values)
    query = f'INSERT INTO mesures_satellites (Parcelle, Territoire, Date, Annee, Latitude, Longitude, PHFB, type_mesure, reference_parcelle) VALUES {insert_estimation_values_string}'
    cursor.execute(query)

    return '1'

# get year of the new measures contained in the specified file
def getYearNewMeasuresFile(newMeasuresFile):
    line = newMeasuresFile.readline() # skip hearder line
    # loop over file lines
    while True:
        line = newMeasuresFile.readline()
        if not line:
            break
        line = line.decode('utf-8')
        attributes = line.split(';')
        # get year
        annee = attributes[2]
    # reset file's pointer to beginning of the file
    newMeasuresFile.seek(0)
    return annee

# delete estimations for all setellite parcels for specified year
def deleteSatelliteEstimationsYear(year, territory):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute('DELETE FROM mesures_satellites WHERE mesures_satellites.annee = ' '"' + year + '"' + ' AND mesures_satellites.type_mesure = "estimation" AND territoire = ' + '"' + territory + '"')
    db_phfb.commit()
    cursor.close()

    return '1'


# delete measures for all reference parcels for specified year
def deleteReferenceMeasuresYear(year, territory):
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    # make request
    cursor.execute('DELETE FROM mesures_references WHERE mesures_references.annee = ' '"' + year + '" AND territoire = ' + '"' + territory + '"')
    db_phfb.commit()
    cursor.close()

    return '1'


def deleteReferenceMeasures(cursor):
    cursor.execute('DELETE FROM mesures_references WHERE mesures_references.annee = ' '"' + year + '"')

    return '1'

def deleteSatelliteMeasures(cursor):
    return '1'

# process estimations for satellite parcels from a specified reference parcel measure
def estimateSatelliteParcelsFromRefParcel(refParcel, territory, refParcelMeasure, date, annee, coeffs):
    # get coeffs where reference parcel = refParcel 
    refParcelCoeffs = list([coeff for coeff in coeffs if coeff['referenceParcel'] == refParcel])

    # process estimation for satellite parcels involved in that coeffs list
    satelliteEstimations = []
    for coeff in refParcelCoeffs:
        # estimation for current satellite parcel and reference parcel
        estimatedPHFB = str(float(refParcelMeasure.replace(',','.')) * float(coeff['coeff']))
        # coordinates of measures done on current satellite parcel
        meanLatitude = coeff['latitude']
        meanLongitude = coeff['longitude']
        satelliteEstimations.append((coeff['satelliteParcel'], territory, date, annee, meanLatitude, meanLongitude, estimatedPHFB, 'estimation', refParcel))

    return satelliteEstimations

# process estimations for (all) satellite parcels from a file containing multiple reference parcel measures (from several reference parcels)
def estimateSatelliteParcelsFromAllRefParcel(refParcelsFile, territory, coeffs, cursor):
    # loop over reference parcels file
    line = refParcelsFile.readline() # skip hearder line
    insert_estimation_values = []
    # loop over file lines
    while True:
        line = refParcelsFile.readline()
        if not line:
            break
        line = line.decode('utf-8')
        attributes = line.split(';')
        # get attributes
        parcel = attributes[0]
        date = attributes[1]
        annee = attributes[2]
        phfb_bilan_hydrique = attributes[6]

        # estimate satellite parcel measures
        insert_estimation_values = insert_estimation_values + estimateSatelliteParcelsFromRefParcel(parcel, territory, phfb_bilan_hydrique, date, annee, coeffs)

    # reset file's pointer to beginning of the file
    refParcelsFile.seek(0) 

    # record satellite estimations
    insert_estimation_values_string = ', '.join(str(t) for t in insert_estimation_values)
    query = f'INSERT INTO mesures_satellites (Parcelle, Territoire, Date, Annee, Latitude, Longitude, PHFB, type_mesure, reference_parcelle) VALUES {insert_estimation_values_string}'
    print('insert_estimation_values: ', len(insert_estimation_values))
    cursor.execute(query)

    return '1'


# get all territories of a specified user
# todo: add in the request the check to only take the territories of the specified user
@app.route('/getTerritories', methods=['GET'])
@jwt_required()
def getTerritories():
    checkConnection(db_phfb)
    cursor = db_phfb.cursor()
    cursor.execute('SELECT * FROM territoires')
    data = cursor.fetchall()
    cursor.close()
    result = []
    for row in data:
        result.append(row[0])
    print('result: ', result)
    return jsonify(result)

    
'run the flask app'
if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')