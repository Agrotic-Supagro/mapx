import mysql.connector
import os

# configure admin database connection
admin_db_config = {
    'user': os.getenv("MYSQL_USER"),
    'password': os.getenv("MYSQL_PASSWORD"),
    'host': os.getenv("MYSQL_HOST"),
    'port': os.getenv("MYSQL_PORT"),
    'database': "administration"
}
db_admin = mysql.connector.connect(**admin_db_config)
db_admin.autocommit = True

# configure ic-apex database connection
icapex_db_config = {
    'user': os.getenv("MYSQL_USER"),
    'password': os.getenv("MYSQL_PASSWORD"),
    'host': os.getenv("MYSQL_HOST"),
    'port': os.getenv("MYSQL_PORT"),
    'database': "icapex"
}
db_icapex = mysql.connector.connect(**icapex_db_config)
db_icapex.autocommit = True

# configure phfb database connection
phfb_db_config = {
    'user': os.getenv("MYSQL_USER"),
    'password': os.getenv("MYSQL_PASSWORD"),
    'host': os.getenv("MYSQL_HOST"),
    'port': os.getenv("MYSQL_PORT"),
    'database': "phfb"
}
db_phfb = mysql.connector.connect(**phfb_db_config)
db_phfb.autocommit = True

# configure root phfb database connection
phfb_db_root_config = {
    'user': "root",
    'password': "root_password",
    'host': os.getenv("MYSQL_HOST"),
    'port': os.getenv("MYSQL_PORT"),
    'database': "phfb"
}
db_phfb_root = mysql.connector.connect(**phfb_db_root_config)
db_phfb_root.autocommit = True

def checkConnection(db):
    db.ping(reconnect = True, attempts=3, delay=10)