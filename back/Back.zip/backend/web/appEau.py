from flask import request, jsonify
from flask_bcrypt import Bcrypt
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
import sys
import uuid

bcrypt = Bcrypt()

# Mapper les noms de colonnes à renommer
column_mapping = {
    'id_utilisateur': 'id',
    'prenom': 'firstname',
    'nom': 'lastname',
    'email': 'email',
    'structure': 'structure',
    'model_ifv': 'ifvModel',
}

@app.route('/getAppEauToken', methods=['POST'])
def getAppEauToken():
    def get_password_from_email(email):
        checkConnection(db_admin)
        cursor = db_admin.cursor()
        cursor.execute('SELECT utilisateur.mot_de_passe FROM utilisateur WHERE utilisateur.email = %s', (email,))
        data = cursor.fetchone()
        return data[0] if data else None

    def get_user_id_from_email(email):
        checkConnection(db_admin)
        cursor = db_admin.cursor()
        cursor.execute('SELECT utilisateur.id_utilisateur FROM utilisateur WHERE utilisateur.email = %s', (email,))
        data = cursor.fetchone()
        return data[0] if data else None

    data = request.get_json()
    if not data:
        return jsonify({'message': 'No data provided'}), 400
    
    email = data.get('email')
    entered_password = data.get('password')

    # Vérifier l'existence de l'email
    if not email:
        return jsonify({'message': 'Email is required'}), 400

    user_password = get_password_from_email(email)

    # Vérifier si le mot de passe existe et s'il existe en utilisant Bcrypt
    if user_password and bcrypt.check_password_hash(user_password, entered_password):
        # TODO : renvoyer le token existant s'il existe plutôt que d'en générer un autre
        token = create_access_token(identity=get_user_id_from_email(email), expires_delta=False)



        return jsonify({'token': token}), 200
    else:
        return jsonify({'message': 'Invalid credentials'}), 401
    



@app.route('/me')
@jwt_required()
def getCurrentUserProfile():
    checkConnection(db_admin)
    cursor = db_admin.cursor()
    
    def get_user_from_id(id):
        cursor.execute('SELECT utilisateur.id_utilisateur, utilisateur.prenom, utilisateur.nom, utilisateur.email, utilisateur.structure, utilisateur.model_ifv FROM utilisateur WHERE utilisateur.id_utilisateur = %s', (id,))
        data = cursor.fetchone()
        return data if data else None

    # Récupère l'id de la personne authentifié grâce à son token
    identity = get_jwt_identity()
    if not identity:
        return jsonify({'message': 'Missing Authorization Header'}), 401

    # Récupérer l'utilisateur
    user = get_user_from_id(identity)
    if not user:
        return jsonify({'message': 'User not found'}), 404

    # Récupérer les noms des colonnes
    column_names = [desc[0] for desc in cursor.description]

    # Créer une liste de dictionnaires associant les noms des colonnes aux valeurs
    result = [dict(zip(column_names, user))]
    user = result[0]

    # Renommer les clés du dictionnaire en utilisant le mapping
    for old_key, new_key in column_mapping.items():
        if old_key in user :
            user[new_key] = user.pop(old_key)

    cursor.close()

    return jsonify(user), 200
