SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- MIGRATE table `utilisateurs`
--

UPDATE administration.utilisateur SET
  `date_creation_ts` = `date_creation`,
  `date_maj_ts` = `date_maj`;

ALTER TABLE administration.utilisateur
  DROP COLUMN `date_creation`,
  DROP COLUMN `date_maj`;

ALTER TABLE administration.utilisateur
  RENAME COLUMN `date_creation_ts` TO `date_creation`,
  RENAME COLUMN `date_maj_ts` TO `date_maj`;

--
-- MIGRATE table `parcelle`
--

UPDATE icapex.parcelle SET
  `date_creation_ts` = `date_creation`,
  `date_maj_ts` = `date_maj`;

ALTER TABLE icapex.parcelle
  DROP COLUMN `date_creation`,
  DROP COLUMN `date_maj`;

ALTER TABLE icapex.parcelle
  RENAME COLUMN `date_creation_ts` TO `date_creation`,
  RENAME COLUMN `date_maj_ts` TO `date_maj`;


--
-- MIGRATE table `session`
--

UPDATE icapex.session SET 
  `date_creation_ts` = `date_creation`,
  `date_maj_ts` = `date_maj`,
  `date_session_temp` = DATE(`date_session`);

ALTER TABLE icapex.session
  DROP COLUMN `date_creation`,
  DROP COLUMN `date_maj`,
  DROP COLUMN `date_session`;

ALTER TABLE icapex.session
  RENAME COLUMN `date_creation_ts` TO `date_creation`,
  RENAME COLUMN `date_maj_ts` TO `date_maj`,
  RENAME COLUMN `date_session_temp` TO `date_session`;


--
-- MIGRATE columns `observation.latitude` and `observation.longitude`
--

UPDATE icapex.session SET
latitude = (
    SELECT latitude
    FROM icapex.observation
    WHERE icapex.session.id_session = icapex.observation.id_session
    LIMIT 1
),
longitude = (
    SELECT longitude
    FROM icapex.observation
    WHERE icapex.session.id_session = icapex.observation.id_session
    LIMIT 1
);

UPDATE icapex.parcelle SET
latitude = (
    SELECT latitude
    FROM icapex.session
    WHERE icapex.parcelle.id_parcelle = icapex.session.id_parcelle
    ORDER BY date_session DESC
    LIMIT 1
),
longitude = (
    SELECT longitude
    FROM icapex.session
    WHERE icapex.parcelle.id_parcelle = icapex.session.id_parcelle
    ORDER BY date_session DESC
    LIMIT 1
);

--
-- MIGRATE table `session_stadepheno`
--

UPDATE icapex.session JOIN icapex.session_stadepheno ON icapex.session.id_session = icapex.session_stadepheno.id_session SET icapex.session.id_stade = icapex.session_stadepheno.id_stade;


--
-- MIGRATE table `commentaire`
--

UPDATE icapex.session JOIN icapex.commentaire ON icapex.session.id_session = icapex.commentaire.id_session SET icapex.session.commentaire = icapex.commentaire.txt_comm;


--
-- MIGRATE table `device`
--

UPDATE icapex.session SET
device_hardware = (
    SELECT CONCAT(device_manufacturer, ' ', device_model)
    FROM icapex.device_info
    WHERE icapex.device_info.id_utilisateur = icapex.session.id_observateur
    ORDER BY id_config DESC
    LIMIT 1
),
device_software = (
    SELECT CONCAT(device_platform, ' ', device_version)
    FROM icapex.device_info
    WHERE icapex.device_info.id_utilisateur = icapex.session.id_observateur
    ORDER BY id_config DESC
    LIMIT 1
);

--
-- OTHERS
--

ALTER TABLE administration.utilisateur
  DROP COLUMN `token`,
  DROP COLUMN `etat`;

ALTER TABLE icapex.session
  DROP COLUMN `etat`;

ALTER TABLE icapex.parcelle
  DROP COLUMN `etat`;

ALTER TABLE icapex.utilisateur_parcelle
  DROP COLUMN `etat`,
  DROP COLUMN `statut`;

DROP TABLE icapex.commentaire;
DROP TABLE icapex.device_info;
DROP TABLE icapex.observation;
DROP TABLE icapex.session_stadepheno;

--
-- TRIGGERS
--
--CREATE TRIGGER `parcelle_insert` BEFORE INSERT ON icapex.parcelle FOR EACH ROW SET new.date_creation = UNIX_TIMESTAMP();
--CREATE TRIGGER `parcelle_update` BEFORE UPDATE ON icapex.parcelle FOR EACH ROW SET new.date_maj = UNIX_TIMESTAMP();

--CREATE TRIGGER `session_insert` BEFORE INSERT ON icapex.session FOR EACH ROW SET new.date_creation = UNIX_TIMESTAMP();
--CREATE TRIGGER `session_update` BEFORE UPDATE ON icapex.session FOR EACH ROW SET new.date_maj = UNIX_TIMESTAMP();


COMMIT;



/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
