SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

set global net_buffer_length=1000000;
set global max_allowed_packet=100000000000000000000000000;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


-- CREATE DATABASE IF NOT EXISTS administration;
-- CREATE DATABASE IF NOT EXISTS icapex;
-- CREATE DATABASE IF NOT EXISTS phfb;

-- GRANT ALL PRIVILEGES ON administration TO '$MYSQL_USER'@'%';
-- GRANT ALL PRIVILEGES ON icapex TO '$MYSQL_USER'@'%';
-- GRANT ALL PRIVILEGES ON phfb TO '$MYSQL_USER'@'%';


COMMIT;

--
-- ADMIN
--

USE administration;

CREATE TABLE utilisateur (
  `id_utilisateur` varchar(60) NOT NULL,
  `prenom` varchar(256) NOT NULL,
  `nom` varchar(256) NOT NULL,
  `email` varchar(256) NOT NULL,
  `mot_de_passe` varchar(2048) NOT NULL,
  `structure` varchar(60) NOT NULL,
  `date_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_maj` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_creation_ts` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_maj_ts` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `token` varchar(2048) NOT NULL,
  `model_ifv` tinyint(1) NOT NULL,
  `etat` int(11) NOT NULL,
  PRIMARY KEY (`id_utilisateur`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


--
-- ICAPEX
--

USE icapex;

CREATE TABLE commentaire (
  `id_comm` int(11) NOT NULL AUTO_INCREMENT,
  `txt_comm` text NOT NULL,
  `id_session` varchar(60) NOT NULL,
  PRIMARY KEY (`id_comm`)
) ENGINE=InnoDB AUTO_INCREMENT=9148 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE device_info (
  `id_config` int(11) NOT NULL AUTO_INCREMENT,
  `device_model` varchar(40) NOT NULL,
  `device_platform` varchar(40) NOT NULL,
  `device_uuid` varchar(40) NOT NULL,
  `device_version` varchar(40) NOT NULL,
  `device_manufacturer` varchar(40) NOT NULL,
  `device_serial` varchar(40) NOT NULL,
  `id_utilisateur` varchar(40) NOT NULL,
  PRIMARY KEY (`id_config`)
) ENGINE=InnoDB AUTO_INCREMENT=1799 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE observation (
  `id_observation` int(11) NOT NULL AUTO_INCREMENT,
  `apex_value` int(11) NOT NULL,
  `latitude` double NOT NULL,
  `longitude` double NOT NULL,
  `id_session` varchar(60) NOT NULL,
  `id_observateur` varchar(60) NOT NULL,
  `etat` int(11) NOT NULL,
  PRIMARY KEY (`id_observation`)
) ENGINE=InnoDB AUTO_INCREMENT=1162520 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE parcelle (
  `id_parcelle` varchar(60) NOT NULL,
  `nom_parcelle` varchar(60) NOT NULL,
  `date_creation` datetime NOT NULL,
  `date_maj` datetime NOT NULL,
  `date_creation_ts` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_maj_ts` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `id_proprietaire` varchar(60) NOT NULL,
  `longitude` DOUBLE NULL,
  `latitude` DOUBLE NULL,
  `etat` int(11) NOT NULL,
  PRIMARY KEY (`id_parcelle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE session (
  `id_session` varchar(60) NOT NULL,
  `date_creation` datetime NOT NULL,
  `date_session` timestamp NOT NULL,
  `date_maj` datetime NOT NULL,
  `date_creation_ts` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_maj_ts` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_session_temp` date NOT NULL,
  `apex0` int(11) NOT NULL,
  `apex1` int(11) NOT NULL,
  `apex2` int(11) NOT NULL,
  `id_observateur` varchar(60) NOT NULL,
  `id_parcelle` varchar(60) NOT NULL,
  `id_stade` varchar(10) NULL,
  `commentaire` text NULL,
  `device_hardware` varchar(60) NULL,
  `device_software` varchar(60) NULL,
  `longitude` DOUBLE NULL,
  `latitude` DOUBLE NULL,
  `en_parcelle` BOOLEAN NULL DEFAULT false,
  `etat` int(11) NOT NULL,
  `date_session_test` timestamp,
  PRIMARY KEY (`id_session`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE session_stadepheno (
  `id_session` varchar(60) NOT NULL,
  `id_stade` varchar(10) NOT NULL,
  PRIMARY KEY (`id_session`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE stadepheno (
  `id_stade` varchar(10) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `resume` text NOT NULL,
  `descriptif` text NOT NULL,
  `url_image` varchar(100) NOT NULL,
  PRIMARY KEY (`id_stade`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE utilisateur_parcelle (
  `id_utilisateur` varchar(60) NOT NULL,
  `id_parcelle` varchar(60) NOT NULL,
  `statut` int(11) NOT NULL,
  `etat` int(11) NOT NULL,
  PRIMARY KEY (`id_utilisateur`, `id_parcelle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;





--
-- PHFB
--

USE phfb;

CREATE TABLE IF NOT EXISTS territoires (
  `nom_territoire` char(40) NOT NULL,
  PRIMARY KEY (`nom_territoire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS parcelles (
  `nom_parcelle` char(40) NOT NULL,
  `territoire` char(40) NOT NULL,
  FOREIGN KEY (territoire) REFERENCES territoires(nom_territoire),
  PRIMARY KEY (`nom_parcelle`,`territoire`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS coefficients (
  `id` int NOT NULL AUTO_INCREMENT,
  `parcel` char(40) NOT NULL,
  `coeff` float NOT NULL,
  `refParcel` char(40) NOT NULL,
  `territoire` char(40) NOT NULL,
  `Latitude` char(40) NOT NULL,
  `Longitude` char(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1254 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS mesures_references (
  `id` int NOT NULL AUTO_INCREMENT,
  `parcelle` char(40) NOT NULL,
  `territoire` char(40) NOT NULL,
  `Date` char(40) NOT NULL,
  `Annee` char(40) NOT NULL,
  `Latitude` char(40) NOT NULL,
  `Longitude` char(40) NOT NULL,
  `PHFB` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `PHFB_bilan_hydrique` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `formatted_date` date GENERATED ALWAYS AS (date_format(str_to_date(`Date`,_utf8mb4'%d/%m/%Y'),_utf8mb4'%Y/%m/%d')) VIRTUAL,
  FOREIGN KEY (parcelle, territoire) REFERENCES parcelles(nom_parcelle, territoire),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1987 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE IF NOT EXISTS mesures_satellites (
  `id` int NOT NULL AUTO_INCREMENT,
  `parcelle` char(40) NOT NULL,
  `territoire` char(40) NOT NULL,
  `Date` char(40) NOT NULL,
  `Annee` char(40) NOT NULL,
  `Latitude` char(40) NOT NULL,
  `Longitude` char(40) NOT NULL,
  `PHFB` char(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `formatted_date` date GENERATED ALWAYS AS (date_format(str_to_date(`Date`,_utf8mb4'%d/%m/%Y'),_utf8mb4'%Y/%m/%d')) VIRTUAL,
  `type_mesure` char(40) DEFAULT NULL,
  `reference_parcelle` char(40) DEFAULT NULL,
  FOREIGN KEY (parcelle, territoire) REFERENCES parcelles(nom_parcelle, territoire),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1987 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



--
-- ADMIN
--

USE administration;

CREATE TABLE utilisateur_parcelle(
    id int NOT NULL AUTO_INCREMENT,
    id_parcelle_icapex VARCHAR(60) NULL, 
    id_utilisateur VARCHAR(60) NOT NULL, 
    id_parcelle_phfb INT NULL,
    statut int(11) NOT NULL, 
    etat int(11) NOT NULL, 
    PRIMARY KEY (`id`)
    -- PRIMARY KEY (id_parcelle_icapex, id_utilisateur, id_parcelle_phfb),
    -- FOREIGN KEY (id_utilisateur) REFERENCES administration.utilisateur(id_utilisateur), 
    -- FOREIGN KEY (id_parcelle_icapex) REFERENCES icapex.parcelle(id_parcelle),
    -- FOREIGN KEY (id_parcelle_phfb) REFERENCES phfb.parcelle(id_parcelle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

