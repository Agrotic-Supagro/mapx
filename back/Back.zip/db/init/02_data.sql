SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- ADMIN
--

USE administration;

INSERT INTO utilisateur (`id_utilisateur`, `prenom`, `nom`, `email`, `mot_de_passe`, `structure`, `date_creation`, `date_maj`, `token`, `model_ifv`, `etat`) VALUES
('cd3ac534-a9f8-4879-9167-5411b981202d', 'Leo', 'Pichon', 'leo.pichon@supagro.fr', '$2y$10$kcT2atTrdOxy1nlSYoxXZObI75tJXn8ea4kO1Jqap9PQOZKBsgSGK', 'chh', '2021-06-17 15:27:51', '2023-06-05 18:37:27', '', 0, 0);

COMMIT;


/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
