echo "** Creating default DB and users"

mariadb -uroot -p$MYSQL_ROOT_PASSWORD --execute \
"CREATE DATABASE IF NOT EXISTS administration;
CREATE DATABASE IF NOT EXISTS icapex;
CREATE DATABASE IF NOT EXISTS phfb;
GRANT ALL PRIVILEGES ON administration.* TO '$MYSQL_USER'@'%';
GRANT ALL PRIVILEGES ON icapex.* TO '$MYSQL_USER'@'%';
GRANT ALL PRIVILEGES ON phfb.* TO '$MYSQL_USER'@'%';"
# DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');"

echo "** Finished creating default DB and users"