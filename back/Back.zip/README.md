# MapX-Vigne

## DEV ENVIRONMENT
### Prerequisites
docker
docker-compose
### Init
Duplicate backend/example.env to backend/.env and set it like you want.
Duplicate db/example.env to db/.env and set it like you want.
If already exists, delete the folder /data
Run `docker-compose build` to build the backend image.
Run `docker-compose up -d`. It creates the containers.
The DB are instantiated with some data from the user "leo.pichon@supagro.fr"

### Access
PhpmyAdmin : `localhost:8080`. Select the DB you want and use the credentials specified in .env file of the DB
Backend : `localhost`
### Change code
Whenever you change something in /backend it automatically reflect in the app. No need to stop the container and to restart. Except if you add requirements in backend. In this case you must rebuild the docker image of the backend with `docker-compose build`

## KNOWN ERRORS
Id database empty and user "user" has access denied it is because the content of 00_init.sh has not been used. If you are on Windows it must be that the file is encoded with End Of File CRLF instead of LF. Open the file and change CRLF to LF then save.
