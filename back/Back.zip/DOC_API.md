# API with Flask (Python)

- BaseUrl local : `http://my_local_ip`
    - Get your IP on Linux bash: `ifconfig`
    - Get your IP on Windows cmd or Powershell: `ipconfig`
- BaseURL pre prod: `http://212.83.176.36:81`
- BaseURL prod: `?`

## Common Endpoints
> ### Login `POST /login`

**Frontend Interface :** `lib/collections/user.collection.dart`

**Database - Tables used :** `utilisateur` from *db_admin*

#### Request body
```json
{
    "email": "",
    "password": "",
}
```
#### Response
```json
{
    "token": "tokenGeneratedByTheBackend",
}
```

> ### Get current user profil `GET /me`

**Frontend Interface :** `lib/collections/user.collection.dart`

**Database - Tables used :** `utilisateur` from *db_admin*

#### Response
```json
{
    "id": "",
    "firstname": "",
    "lastname": "",
    "email": "",
    "structure": "",
    "ifvModel": "",
}
```

## Web Endpoints
- ...

## Mobile Endpoints

> ### Create a parcel `POST /parcels/<id>`

**Frontend Interface :** `lib/collections/parcel.collection.dart`

**Database - Tables used :** `parcelle` from *db_icapex*

#### Parameters
- `id`: Id of the parcel

#### Request body
```json
{
    "name": "",
}
```
#### Response
```json
{
    "id": "parcelIdCreatedByDatabase",
}
```

> ### Create a session `POST /sessions/<id>`

**Frontend Interface :** `lib/collections/session.collection.dart`

**Database - Tables used :** `session`  from *db_icapex* | `?commentaire`from *db_icapex* | `?session_stadepheno` from *db_icapex*

#### Parameters
- `id`: Id of the session

#### Request body
```json
{
    "id": 0,
    "createdAt": "", // DateTime format managed by the backend
    "sessionDate": "",
    "updatedAt": "", // DateTime format managed by the backend
    "apexFullGrowth": 0,
    "apexSlowerGrowth": 0,
    "apexStuntedGrowth": 0,
    "observerId": 0, // User ID managed by the backend
    "parcelId": 0,

    ====Necessary for the frontend and the database ?====
    "isOnline": true,
    =====================================================
},
```

> ### Update a session `PUT /sessions<id>`

**Frontend Interface :** `lib/collections/session.collection.dart`

**Database - Tables used :** `session`  from *db_icapex* | `?commentaire`from *db_icapex* | `?session_stadepheno` from *db_icapex*

##### Parameters
- `id`: Id of the session

#### Request body
```json
{
    "id": 0,
    "createdAt": "", // DateTime format managed by the backend
    "sessionDate": "",
    "updatedAt": "", // DateTime format managed by the backend
    "apexFullGrowth": 0,
    "apexSlowerGrowth": 0,
    "apexStuntedGrowth": 0,
    "observerId": 0, // User ID managed by the backend
    "parcelId": 0,

    ====Necessary for the frontend and the database ?====
    "isOnline": true,
    =====================================================
},
```

#### Response
```json
{
    "id": "sessionIdByDatabase",
}
```

> ### Get all parcels for the user `GET /parcels`

**Frontend Interface :** List of `lib/collections/parcel.collection.dart`

**Database - Tables used :** `parcelle` from *db_icapex*

#### Response
```json
[
    {
        "id": 0,
        "name": "",
        "createdAt": "",
        "updatedAt": "",
        "ownerId": 0,

        ====Necessary for the frontend and the database ?====
        "isOnline": true,
        =====================================================
    },
    {...},
    {...}
]
```

> ### Get one parcel by id for the user `GET /parcels/<id>`

**Frontend Interface :** `lib/collections/parcel.collection.dart`

**Database - Tables used :** `parcelle` from *db_icapex*

##### Parameters
- `id`: Id of the parcel

#### Response
```json
{
    "id": 0,
    "name": "",
    "createdAt": "",
    "updatedAt": "",
    "ownerId": 0,

    ====Necessary for the frontend and the database ?====
    "isOnline": true,
    =====================================================
},
```


> ### Get all sessions `GET /sessions`

**Frontend Interface :** List of `lib/collections/session.collection.dart`

**Database - Tables used :** `session`  from *db_icapex* | `?commentaire`from *db_icapex* | `?session_stadepheno` from *db_icapex*

#### Response
```json
[
    {
        "id": 0,
        "createdAt": "",
        "sessionDate": "",
        "updatedAt": "",
        "apexFullGrowth": 0,
        "apexSlowerGrowth": 0,
        "apexStuntedGrowth": 0,
        "observerId": 0,
        "parcelId": 0,

        ====Necessary for the frontend and the database ?====
        "isOnline": true,
        =====================================================
    },
    {...},
    {...}
]
```


> ### Get one session by id `GET /sessions/<id>`

**Frontend Interface :** `lib/collections/session.collection.dart`

**Database - Tables used :** `session`  from *db_icapex* | `?commentaire`from *db_icapex* | `?session_stadepheno` from *db_icapex*

##### Parameters
- `id`: Id of the session

#### Response
```json
{
    "id": 0,
    "createdAt": "",
    "sessionDate": "",
    "updatedAt": "",
    "apexFullGrowth": 0,
    "apexSlowerGrowth": 0,
    "apexStuntedGrowth": 0,
    "observerId": 0,
    "parcelId": 0,

    ====Necessary for the frontend and the database ?====
    "isOnline": true,
    =====================================================
},
```
